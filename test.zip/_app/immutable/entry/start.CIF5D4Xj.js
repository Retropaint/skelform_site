import{l as o,a as r}from"../chunks/o2CvYQxU.js";export{o as load_css,r as start};
