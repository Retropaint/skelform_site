import{l as o,a as r}from"../chunks/J7ll5MI9.js";export{o as load_css,r as start};
