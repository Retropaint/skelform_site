import{l as o,a as r}from"../chunks/DW4WB1HV.js";export{o as load_css,r as start};
